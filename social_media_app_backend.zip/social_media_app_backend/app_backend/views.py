from django.shortcuts import render, redirect
from django.contrib.auth.decorators import login_required
from django.contrib.auth import authenticate, login
from django.contrib import messages
from .forms import ProfileForm
from .models import Profile

#<---------------for home page------------------->
def home(request):
    if request.method == "POST":
        username = request.POST['username']
        password = request.POST['password']
        user = authenticate(request, username=username, password=password)
        if user is not None:
            login(request, user)
            return redirect('profile')  # this will redirect to the profile page if login is successful
        else:
            messages.error(request, "Invalid username or password.")  # display error msg
    return render(request, 'home.html')

#<---------------for profile page------------------->
@login_required
def profile(request):
    profile = Profile.objects.get(user=request.user)
    if request.method == 'POST':
        form = ProfileForm(request.POST, request.FILES, instance=profile)
        if form.is_valid():
            form.save() 
            return redirect('profile')  # this will redirec to the profile page after saving
    else:
        form = ProfileForm(instance=profile)  # if profile exist then pre-fill the form 

    return render(request, 'profile.html', {'form': form, 'profile': profile})
